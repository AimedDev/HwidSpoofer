﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Helix_Spoofer
{
    public partial class spoofeac_loader : Form
    {


        

        public spoofeac_loader()
        {
            InitializeComponent();
            timer1.Start();
        }

        private void spoofeac_loader_Load(object sender, EventArgs e)
        {
            Process.Start("taskkill", "/F /IDA Freeware 7.7");

            Process.Start("taskkill", "/F /ida64");

            Process[] dnSpy = Process.GetProcessesByName("dnSpy");
            foreach (Process worker in dnSpy)
            {
                worker.Kill();
            }


            Process[] CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE = Process.GetProcessesByName("HTTP Debugger");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }


            Process[] CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE = Process.GetProcessesByName("Fiddler");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE = Process.GetProcessesByName("x96dbg");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE = Process.GetProcessesByName("x64dbg");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE = Process.GetProcessesByName("HxD");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE = Process.GetProcessesByName("Hexy");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE = Process.GetProcessesByName("dotPeek64");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE = Process.GetProcessesByName("dotPeek32");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE = Process.GetProcessesByName("cheatengine-x86_64-SSE4-AVX2");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] eeCEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE = Process.GetProcessesByName("Cheat Engine");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEeeEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE = Process.GetProcessesByName("cheatengine-i386");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE = Process.GetProcessesByName("cheatengine-x86_64");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }
            Process[] CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE = Process.GetProcessesByName("windowsrepair");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE = Process.GetProcessesByName("ida64");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEeEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE = Process.GetProcessesByName("x64dbg");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }


            Process[] CEEEEEEEEEEEEEeEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE = Process.GetProcessesByName("dnSpy");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }


            Process[] CEEEEEEEEEEEEEeEEEEEEEEEEeeEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE = Process.GetProcessesByName("FolderChangesView");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEeEEEEEEEEeEeeEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE = Process.GetProcessesByName("BinaryNinja");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }


            Process[] CEEEEEEEEEEEEEeEEEEEEEEeEeeEeeeEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE = Process.GetProcessesByName("Cheat Engine 7.4");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEeEEEEEEEEeEeeEeeeEeeEEEEEEEEEEEEEEEEEEEEEEEEEEEEE = Process.GetProcessesByName("Process Hacker");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEeEEEEEEEEeEeeEeeeEeeEEEEEEEEEEEEEEEEEeeEEEEEEEEEEEE = Process.GetProcessesByName("Process Hacker 1");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEeEEEEEEEEeEeeEeeeeeeeEeeEEEEEEEEEEEEEEEEEEEEEEEEEEEEE = Process.GetProcessesByName("Process Hacker 2");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEeEEEEEEEEeeeeeeEeeEeeeeeeeEeeEEEEEEEEEEEEEEEEEEEEEEEEEEEEE = Process.GetProcessesByName("OllyDbg");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEeEEEeeeEEEEEeeeeeeEeeEeeeeeeeEeeEEEEEEEEEEEEEEEEEEEEEEEEEEEEE = Process.GetProcessesByName("Spy");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEeEEEeeeEEEEEeeeeeeEeeEeeeeeeeEeeEEEEEEEEEEEEEEeEEEEEEEEEEEEEEE = Process.GetProcessesByName("Debugger");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }


            Process[] CEEEEEEEEEEEEEeEEEeeeEEEEEeeeeeeEeeEeeeeeeeEeeEEEEEEEEEEEEeeEEeEEEEEEEEEEEEEEE = Process.GetProcessesByName("Xenon");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }


            Process[] CEEEEEEEEEEEEEeEEEeeeEEEEEeeeeeeEeeeEeeeeeeeEeeEEEEEEEEEEEEeeEEeEEEEEEEEEEEEEEE = Process.GetProcessesByName("xdebug");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEeEEEeeeEEEEEeeeeeeeeEeeeEeeeeeeeEeeEEEEEEEEEEEEeeEEeEEEEEEEEEEEEEEE = Process.GetProcessesByName("ida");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEeEEEeeeEEEEEeeeeeeeeEeeeEeeeeeeeEeeEEEEEEEeeeEEEEEeeEEeEEEEEEEEEEEEEEE = Process.GetProcessesByName("CocoaDebug");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }


            Process[] CEEEEEEEEEEEEEeEEEeeeEEEEEeeeeeeeeeeEeeeEeeeeeeeEeeEEEEEEEeeeEEEEEeeEEeEEEEEEEEEEEEEEE = Process.GetProcessesByName("x32dbg");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }


            Process[] CEEEEEEEEEEEEEeEEEeeeEEEEEeeeeeeeeeeEeeeEeeeeeeeEeeEEEEEEeeeEeeeEEEEEeeEEeEEEEEEEEEEEEEEE = Process.GetProcessesByName("krzydbg");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEeEEEeeeEEEEEeeeeeeeeeeEeeeEeeeeeeeeeEeeEEEEEEeeeEeeeEEEEEeeEEeEEEEEEEEEEEEEEE = Process.GetProcessesByName("OllyDBG");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEeEEEeeeEEEEEeeeeeeeeeeEeeeEeeeeeeeeeEeeEEEEEEeeeEeeeeeEEEEEeeEEeEEEEEEEEEEEEEEE = Process.GetProcessesByName("die");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }


            Process[] CEEEEEEEEEEEEEeEEEeeeEEEEEeeeeeeeeeeEeeeeeEeeeeeeeeeEeeEEEEEEeeeEeeeeeEEEEEeeEEeEEEEEEEEEEEEEEE = Process.GetProcessesByName(".NET Reflector");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEeEEEeeeEEEEEeeeeeeeeeeEeeeeeEeeeeeeeeeEeeEEEEEEeeeeEeeeeeEEEEEeeEEeEEEEEEEEEEEEEEE = Process.GetProcessesByName("4fr33");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEeEEEeeeEEEEEeeeeeeeeeeEeeeeeeeeEeeeeeeeeeEeeEEEEEEeeeeEeeeeeEEEEEeeEEeEEEEEEEEEEEEEEE = Process.GetProcessesByName("HxD64");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEeEEEeeeEEEEEeeeeeeeeeeeeEeeeeeeeeEeeeeeeeeeEeeEEEEEEeeeeEeeeeeEEEEEeeEEeEEEEEEEEEEEEEEE = Process.GetProcessesByName("HxD32");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEeEEEeeeEEEEEeeeeeeeeeeeeEeeeeeeeeEeeeeeeeeeeeEeeEEEEEEeeeeEeeeeeEEEEEeeEEeEEEEEEEEEEEEEEE = Process.GetProcessesByName("PE-bear");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEeEEEeeeEEEEEeeeeeeeeeeeeEeeeeeeeeEeeeeeeeeeeeEeeeEEEEEEeeeeEeeeeeEEEEEeeEEeEEEEEEEEEEEEEEE = Process.GetProcessesByName("HWorks32");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEeEEEeeeEEEEEeeeeeeeeeeeeEeeeeeeeeEeeeeeeeeeeeEeeeEEEEEEeeeeEeeeeeeeEEEEEeeEEeEEEEEEEEEEEEEEE = Process.GetProcessesByName("CFF Explorer");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEeEEEeeeEEEEEeeeeeeeeeeeeeeeeEeeeeeeeeEeeeeeeeeeeeEeeeEEEEEEeeeeEeeeeeEEEEEeeEEeEEEEEEEEEEEEEEE = Process.GetProcessesByName("winhex");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }


            Process[] CEEEEEEEEEEEEEeEEEeeeEEEEEeeeeeeeeeeeeeeeeEeeeeeeeeEeeeeeeeeeeeEeeeEEEEEEeeeeEeeeeeEEEeeEEeeEEeEEEEEEEEEEEEEEE = Process.GetProcessesByName("vsd_win32");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEeEEEeeeEEEeeEEeeeeeeeeeeeeeeeeEeeeeeeeeEeeeeeeeeeeeEeeeEEEEEEeeeeEeeeeeEEEeeEEeeEEeEEEEEEEEEEEEEEE = Process.GetProcessesByName("PETools");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEeEEEeeeEEEeeEEeeeeeeeeeeeeeeeeEeeeeeeeeEeeeeeeeeeeeEeeeEEEEeeeEEeeeeEeeeeeEEEeeEEeeEEeEEEEEEEEEEEEEEE = Process.GetProcessesByName("nfd");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEeEEEeeeEEEeeEEeeeeeeeeeeeeeeeeeeeEeeeeeeeeEeeeeeeeeeeeEeeeEEEEeeeEEeeeeEeeeeeEEEeeEEeeEEeEEEEEEEEEEEEEEE = Process.GetProcessesByName("ResourceHacker");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEeEEEeeeEEEeeEEeeeeeeeeeeeeeeeeeeeeeEeeeeeeeeEeeeeeeeeeeeEeeeEEEEeeeEEeeeeEeeeeeEEEeeEEeeEEeEEEEEEEEEEEEEEE = Process.GetProcessesByName("ESEADriver2");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEeEEEeeeEEEeeEEeeeeeeeeeeeeeeeeeeeeeEeeeeeeeeEeeeeeeeeeeeEeeeEEEEeeeEEeeeeEeeeeeEEEeeEEeeEEeEeeEEEEEEEEEEEEEE = Process.GetProcessesByName("Injector");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

            Process[] CEEEEEEEEEEEEEeEEEeeeEEEeeEEeeeeeeeeeeeeeeeeeeeeeEeeeeeeeeEeeeeeeeeeeeEeeeEEeeeEeeeEEeeeeEeeeeeEEEeeEEeeEEeEeeEEEEEEEEEEEEEE = Process.GetProcessesByName("Extrem Injector");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            gunaProgressBar1.Value += 5;


            if (gunaProgressBar1.Value >= 5)
            {
                drc.Text = "authenicating with server, loading modules.";
            }






            if (gunaProgressBar1.Value >= 65)
            {
                drc.Text = "verifying application integrity, checking...";
            }

            if (gunaProgressBar1.Value >= 95)
            {
                drc.Text = "Checking Whitelist...";
            }

            if (gunaProgressBar1.Value >= 115)
            {
                drc.Text = "Checking for Software-Updates...";
            }

            if (gunaProgressBar1.Value >= 135)
            {
                drc.Text = "Checking for Debuggers...";
            }



            if (gunaProgressBar1.Value == 140)
            {
                Spoof main = new Spoof();
                main.Show();
                this.Hide();

                timer1.Enabled = false;
            }
        }

        private void guna2PictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void drc_Click(object sender, EventArgs e)
        {

        }
    }
}
