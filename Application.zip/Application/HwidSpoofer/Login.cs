﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HwidSpoofer;
using KeyAuth;

namespace Helix_Spoofer
{



    public partial class Login : Form
    {
public static api KeyAuthApp = new api(
   name: "helix",
   ownerid: "aJ8GENnpvu",
   secret: "0fce8dec834ae3185bc3e399ff8790300b4ac871ffb6f9483463a9292a55519f",
   version: "1.0"
);


        public Login()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            siticoneShadowForm1.SetShadowForm(this);
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            KeyAuthApp.login(username.Text, password.Text);
            if (KeyAuthApp.response.success)
            {
                Loading main = new Loading();
                main.Show();
                this.Hide();
            }
            else
            {
                incorrect_msg main = new incorrect_msg();
                main.Show();
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {
            KeyAuthApp.init();
            TopMost = true;
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            KeyAuthApp.register(username.Text, password.Text, key.Text);
            if (KeyAuthApp.response.success)
            {
                Loading main = new Loading();
                main.Show();
                this.Hide();
            }
            else
            {
                incorrect_msg main = new incorrect_msg();
                main.Show();
            }
        }
    }
}
