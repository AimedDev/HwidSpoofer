﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using KeyAuth;
using Microsoft.Win32;

namespace Helix_Spoofer
{
    public partial class Loading : Form
    {

 public static api KeyAuthApp = new api(
   name: "helix",
   ownerid: "aJ8GENnpvu",
   secret: "0fce8dec834ae3185bc3e399ff8790300b4ac871ffb6f9483463a9292a55519f",
   version: "1.0"
);

        public Loading()
        {
            InitializeComponent();
            timer1.Start();
        }

        WebClient wc = new WebClient();
        private string defPath = Application.StartupPath + "//Monaco//";

        private void Loading_Load(object sender, EventArgs e)
        {
            KeyAuthApp.init();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            gunaProgressBar1.Value += 5;


            if (gunaProgressBar1.Value >= 5)
            {
                drc.Text = "authenicating with server, loading modules.";
            }






            if (gunaProgressBar1.Value >= 65)
            {
                drc.Text = "verifying application integrity, checking...";
            }

            if (gunaProgressBar1.Value >= 95)
            {
                drc.Text = "verifying your OS information...";
                label1.Text = "Welcome, " + Login.KeyAuthApp.user_data.username;
            }

            if (gunaProgressBar1.Value >= 115)
            {
                drc.Text = "retrieving software status...";
            }

            if (gunaProgressBar1.Value >= 135)
            {
                drc.Text = "retrieving your licenses...";
            }



            if (gunaProgressBar1.Value == 140)
            {
                Main main = new Main();
                main.Show();
                this.Hide();

                timer1.Enabled = false;
            }
        }

        private void webBrowser122_Click(object sender, EventArgs e)
        {

        }

        private void guna2PictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void drc_Click(object sender, EventArgs e)
        {

        }
    }
}
